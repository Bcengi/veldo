#!/usr/bin/env python3
"""VELDO init scaffolder: stand up the VELDO substrate in a fresh repository.

One mechanical step lays the canonical gate, the contract validator, the
capability manifest, the spec templates, an empty starter plan, and the
repository instructions from the plugin templates, producing a repository
whose own gate runs green with no product code in it yet.

Proportionate by design: this reuses the shipped templates as the single
source of truth (it copies them, it does not reimplement any gate, validator,
or index logic) and depends only on the standard library. It NEVER overwrites
an existing file, so it is idempotent and safe to re-run; the derived spec
index is the one file it (re)generates, by invoking the target's own
generator, so the index reflects reality after every run.

The interactive /veldo:init skill remains the front door that configures the
gate slots and protected paths with a human. This module is the mechanical
scaffolder that skill, or an adopting human, can call directly.

Usage:
  python3 .veldo/init_scaffold.py <target-dir>
"""
import importlib.util
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# WHERE THE TEMPLATES ARE DEPENDS ON WHICH SHAPE THIS IS RUNNING IN, and there are exactly two.
# In THIS repository the base is a separate tree at engine/ and this file is our own instance.
# In a PUBLISHED PACK the base has been composed INTO the pack, so the pack root IS the template
# source and there is no engine/ directory at all. Assuming engine/ made init unusable in the very
# artifact an adopter receives: it failed with "templates not found" in a composed pack, which is
# the only place a stranger ever runs it. Found by initialising a published pack and running the
# loop, which is what W6 requires and what nothing before had done.
DEFAULT_TEMPLATES = ROOT / "engine" if (ROOT / "engine").is_dir() else ROOT


class ScaffoldError(RuntimeError):
    """A scaffold could not be laid faithfully. Raised loud, never swallowed,
    so a broken substrate is never mistaken for a green one."""


# Individual template files to lay down (source path == destination path,
# relative to the templates root and the target root respectively).
_FILES = [
    "CLAUDE.md",
    "VELDO.md",
    ".veldo/validate.py",
    ".veldo/validate_checks.py",
    # VELDO-0016 (PLAN-0019 W1): the project-layer policy contract, loaded by the suite and by
    # the packages above it; laid down beside the loader whose adapters it registers. Not in
    # REQUIRED_SUBSTRATE: no gate stage of validate_checks loads it. The LOADER it registers the
    # adapters of, contract_loader.py, IS loaded eagerly by validate_checks and is substrate.
    ".veldo/policy_contract.py",
    ".veldo/contract_loader.py",
    # VELDO-0017 (PLAN-0019 W2): entity identity and lifecycle schemas, loaded by the suite and by
    # the store above it; not substrate (no gate stage of validate_checks loads it).
    ".veldo/entity_contract.py",
    # VELDO-0018 (PLAN-0019 W3): release and behavior-floor integration contracts, loaded by the
    # suite and by the release execution store above it; not substrate.
    ".veldo/release_floor_contract.py",
    # VELDO-0019 (PLAN-0019 W4): the combined dependency graph and decision observation rules,
    # loaded by the suite and by the eligibility service above it; not substrate.
    ".veldo/graph_contract.py",
    # VELDO-0020 (PLAN-0019 W5): signing and authority contracts, loaded by the suite and by the
    # authority service above it; not substrate.
    ".veldo/authority_contract.py",
    # VELDO-0022 (PLAN-0019 W7): Section 2 admission semantics, loaded by the suite and by the Admission
    # Service above it; not substrate.
    ".veldo/admission_contract.py",
    # VELDO-0021 (PLAN-0019 W6): completion and eligibility predicates, loaded by the suite and by the
    # eligibility service and lander above it; not substrate.
    ".veldo/completion_contract.py",
    # VELDO-0023 (PLAN-0019 W8): the control store and the journal replay, the durable control
    # foundation's first two organs; loaded by the suite and by the authority process above it.
    ".veldo/control_store.py",
    # VELDO-0036: authority reservations and the subscription invocation seam.
    ".veldo/control_reservations.py",
    ".veldo/control_reservation_runtime.py",
    # VELDO-0035: accepted snapshots and transactional read-set registrations.
    # Runtime assets; no validator import, so not REQUIRED_SUBSTRATE.
    ".veldo/control_snapshot.py",
    ".veldo/control_readset.py",
    # VELDO-0043: the plain-data graph adapter and its isolated-enforcement command.
    # Runtime assets; no validator import, so not REQUIRED_SUBSTRATE.
    ".veldo/control_graph.py",
    ".veldo/control_graph_isolation.py",
    # VELDO-0043: the exact runtime lock (data), its per-account installer, and the LangGraph
    # runner the adapter launches under the locked interpreter. No validator import.
    ".veldo/control_graph_lock.py",
    ".veldo/control_graph_install.py",
    ".veldo/control_graph_langgraph.py",
    # VELDO-0132: versioned workflow definitions and their revisions, cycles bound to one exact
    # revision, and the step kinds spliced into the LangGraph runner. No validator import.
    ".veldo/control_workflow.py",
    ".veldo/control_workflow_cycle.py",
    ".veldo/control_workflow_langgraph.py",
    # VELDO-0045: activation of that runtime against its license and provenance records (laid down
    # from _RUNTIME_ASSETS below), the qualification workload and the no-runtime enforcement check.
    # Runtime asset; no validator import, so not REQUIRED_SUBSTRATE.
    ".veldo/control_runtime.py",
    # VELDO-0045: the installed authorization entry and every module its two-key path loads, so the
    # enforcement the runtime must never reach is installed and can be run with the runtime hidden.
    # authorization.py ships inert (no human_decisions policy block); none is a validator import.
    ".veldo/authorization.py",
    ".veldo/two_key.py",
    ".veldo/action.py",
    ".veldo/action_executor.py",
    ".veldo/evidence.py",
    ".veldo/execution_binding.py",
    ".veldo/incident.py",
    # VELDO-0037: alias allocation commands and accepted-document publication; runtime assets
    # loaded by the authority, not by the validator, so not REQUIRED_SUBSTRATE.
    ".veldo/control_alias.py",
    ".veldo/control_document.py",
    # VELDO-0029's enrollment binding, which control_document reads to bind a checkout to the
    # repository it is enrolled as.
    ".veldo/control_enrollment.py",
    # VELDO-0052: the shared floor eligibility service executor.py, plan.py and work_state.py load
    # (with frontier, work and dispatch); a runtime asset, no validator import, not substrate.
    ".veldo/control_eligibility.py",
    # VELDO-0054: exact decision-record dependency evaluation control_eligibility.py loads; a runtime
    # asset, no validator import, not substrate.
    ".veldo/control_decision_dependency.py",
    # VELDO-0134: the architecture record's schema and its one writer, which control_eligibility.py
    # loads; a runtime asset, no validator import at load, not substrate.
    ".veldo/control_architecture.py",
    # VELDO-0050: accepted proof bundles and complete contextual proof validation, which executor.py
    # loads; a runtime asset, no validator import, not substrate.
    ".veldo/control_proof.py",
    # VELDO-0058: the installed gate run against a candidate in candidate mode, its external
    # observation and acceptance, and the installed policy, which lander.py and executor.py load; a
    # runtime asset, no validator import, not substrate.
    ".veldo/control_verification.py",
    # VELDO-0051: the journal projection that publishes spec.shipped from a confirmed landing receipt
    # (it loads events.py, completion_contract.py and control_store.py); a runtime asset, no validator
    # import, not substrate.
    ".veldo/control_event_projection.py",
    # VELDO-0057: the exact-tip publication and the confirmed-landing receipt a factory land completes
    # through (it loads control_event_projection.py, completion_contract.py, control_eligibility.py and
    # control_effect_executor.py); a runtime asset, no validator import, not substrate.
    ".veldo/control_landing.py",
    # VELDO-0039: dispatch records and the runner/receiver launch path; runtime assets the
    # receiver process executes, no validator import, so not REQUIRED_SUBSTRATE.
    ".veldo/control_dispatch.py",
    ".veldo/control_launch.py",
    # VELDO-0040: worker profiles, containment groups, caps and group stop the receiver calls; a
    # runtime asset, no validator import, not REQUIRED_SUBSTRATE.
    ".veldo/control_containment.py",
    # VELDO-0041: the trusted wrapper's heartbeat and the receiver's watch of it, and the retirement
    # of worker slots, which control_launch.py loads; runtime assets, no validator import, not
    # REQUIRED_SUBSTRATE.
    ".veldo/control_heartbeat.py",
    ".veldo/control_retirement.py",
    # VELDO-0042: isolated worker clones at the accepted commit over pinned per-repository object
    # caches, and the Landlock wrapper that keeps a worker's direct writes off other clones, the store,
    # the keys, the authority's Git metadata and the caches; the lifecycle base it builds on
    # (env_provision). Runtime assets, no validator import, not REQUIRED_SUBSTRATE.
    ".veldo/control_clone.py",
    ".veldo/env_provision.py",
    # VELDO-0047: the authority service (install, explicit start and stop, one instance under the
    # store's stable lock, signed commands applied to the configured store) and the systemd user unit
    # template it renders. Runtime assets the installer copies into its fixed executable; no
    # validator import, so not REQUIRED_SUBSTRATE.
    ".veldo/control_service.py",
    ".veldo/services/veldo-authority.service",
    # VELDO-0138: the service's Telegram channel, which runs the VELDO-0073 ingress and applies the
    # owner's activation commands; loaded by control_service.py, so part of its fixed executable.
    ".veldo/control_service_channel.py",
    # VELDO-0130 phase 3: the service's side of the authenticated API, which runs the API's commands and
    # reads and sends it the post-commit hint; loaded by control_service.py, so part of its fixed executable.
    ".veldo/control_service_api.py",
    # The one owner of where the owner's systemd user units live, which the authority installer
    # loads for its default unit directory. The installer copies every module its programs load
    # (control_service.closure()), so what it loads is laid down with it; no validator import, so not
    # REQUIRED_SUBSTRATE.
    ".veldo/supervisor.py",
    # VELDO-0031: authority claim receiver and caller, not loaded by validators.
    ".veldo/control_claim.py",
    ".veldo/control_claim_client.py",
    ".veldo/control_client.py",
    # VELDO-0046: ordinary committed-event delivery; no validator loads this module.
    ".veldo/control_notify.py",
    # VELDO-0064: the assignment inbox and its Telegram projection; no validator loads them.
    ".veldo/control_assignment.py",
    ".veldo/control_channel_projection.py",
    # VELDO-0065: versioned presentation receipts and presentation-bound answers; no validator loads it.
    ".veldo/control_channel_presentation.py",
    # VELDO-0066: canonical Telegram acquisition and sender attribution; no validator loads it.
    ".veldo/control_channel_attribution.py",
    # VELDO-0126: the one Telegram and API message intake for proposed work; no validator loads it.
    ".veldo/control_intake.py",
    ".veldo/control_replay.py",
    # VELDO-0024 (PLAN-0019 W9): the signed replica publisher, the store's publication cursor's
    # only client; loaded by the suite, the status reader and the authority process above it.
    ".veldo/control_replica.py",
    # VELDO-0025 (PLAN-0019 W10): the membership organ, the authority's administrative command path;
    # loaded by the suite and by the authority process above it.
    ".veldo/control_membership.py",
    # VELDO-0026 (PLAN-0019 W11): the revocation organ, the acceptance guard every boundary invokes;
    # loaded by the suite and by the authority process above it.
    ".veldo/control_revocation.py",
    # VELDO-0028: protected effects and their signing/issuer dependency closure.
    # Runtime assets, not validator imports: REQUIRED_SUBSTRATE is unchanged.
    ".veldo/control_keys.py",
    ".veldo/control_signer.py",
    # VELDO-0067: the restricted channel edge enrollment, the protected signer's answer purpose it
    # loads, and the custody wrapper that keeps a worker from reading a protected key directory.
    # Runtime assets the authority and the signer load; no validator import, so not REQUIRED_SUBSTRATE.
    ".veldo/control_channel_enrollment.py",
    ".veldo/control_signer_answers.py",
    ".veldo/control_keys_custody.py",
    # VELDO-0068: the one request settlement service (terms, API answers, the terminal transaction and
    # the published request state). A runtime asset the authority loads; not validator substrate.
    ".veldo/control_request_settlement.py",
    # VELDO-0130: the authenticated API (the loopback HTTP service, passkey verification, the
    # api_credential store kind, the typed API assertion, the protected signer's "api" purpose, the
    # authority's judgment of it, and the published read models and UI action contract). Runtime assets the API, the signer and the authority load; no
    # validator imports them, so none is REQUIRED_SUBSTRATE.
    ".veldo/control_api.py",
    ".veldo/control_api_assertion.py",
    ".veldo/control_api_authority.py",
    ".veldo/control_api_credentials.py",
    ".veldo/control_api_models.py",
    ".veldo/control_api_signer.py",
    ".veldo/control_api_webauthn.py",
    # VELDO-0130 phase 3: the API process's client of the authority service socket and its hint socket.
    ".veldo/control_client_api.py",
    # VELDO-0073: the Telegram edge's activation gate, qualification record and activated ingress (the
    # production construction of the settlement path). Runtime assets the authority loads; not substrate.
    ".veldo/control_channel_activation.py",
    ".veldo/control_channel_ingress.py",
    # VELDO-0139: the owner's one setup of a real factory on this host (veldo factory setup), which orders
    # and checks the pieces above. An owner command, not loaded by the service or any validator, so not
    # REQUIRED_SUBSTRATE.
    ".veldo/control_factory_setup.py",
    ".veldo/control_andon.py",
    # VELDO-0076: the project service (activation, pause, resume, cancel, completion). A runtime asset
    # the authority loads; no validator import, so not REQUIRED_SUBSTRATE.
    ".veldo/control_project.py",
    # VELDO-0077: the objective service (acceptance through settlement, bounded elaboration, evidence
    # assessment and cancellation). A runtime asset the authority loads; not validator substrate.
    ".veldo/control_objective.py",
    ".veldo/credential_issue.py",
    ".veldo/control_effects.py",
    ".veldo/control_effect_executor.py",
    # VELDO-0104 (PLAN-0020 W4): the fix-validation record and the rule the proof check applies.
    # validate_checks registers its loader, so a scaffolded repository without it has no proof stage;
    # and it loads the runner by path, which loads the capsule module, so all three travel together.
    ".veldo/fix_validation_record.py",
    ".veldo/git_process.py",
    ".veldo/yamlish.py",
    ".veldo/fix_validation.py",
    ".veldo/capsule.py",
    ".veldo/verdict_corpus.py",
    ".veldo/events.py",
    # VELDO-0051: the canonical event vocabulary events.py and validate.py both load.
    ".veldo/control_event_vocabulary.py",
    ".veldo/arch.py",
    ".veldo/decision.py",
    ".veldo/request.py",
    ".veldo/decision_review.py",
    ".veldo/observability.py",
    ".veldo/secret_inventory.py",
    ".veldo/secret_scan.py",
    ".veldo/shape_review.py",
    ".veldo/security_review.py",
    ".veldo/shape_gate.py",
    ".veldo/tripwire.py",
    ".veldo/tracker.py",
    # VELDO-0012 and VELDO-0011: validate_checks loads both organs, so a scaffolded
    # repository missing them raises FileNotFoundError the first time run_all reaches the
    # check. Derived, not remembered: the suite reads validate_checks for its literal
    # loader paths and reds if either list omits one.
    ".veldo/behavior_floor.py",
    ".veldo/release_contract.py",
    # VELDO-0002 and VELDO-0003. Laid down but deliberately NOT in REQUIRED_SUBSTRATE: no gate
    # stage loads either, so a missing copy cannot redden a gate run, and claiming otherwise would
    # be a false requirement.
    ".veldo/work_state.py",
    ".veldo/tasks.py",
    # THE ORGANS work_state.py LOADS, ADDED 2026-08-13 BECAUSE IT CRASHED WITHOUT THEM. Ledger
    # finding 61: init laid work_state.py down and laid down neither of these, so PLAN-0018's
    # headline command exited 1 with `FileNotFoundError: .veldo/executor.py` in every adopter tree.
    # MEASURED on a fixture carrying exactly what init lays down, before this line existed.
    # An organ whose loader ships without it is not a smaller install, it is a broken one, and
    # VELDO-0007's stage could not see it because that stage proves the adopter's GATE runs rather
    # than that the product runs. Dmitry directed both repairs on 2026-08-13: these two ship, AND
    # work_state names an absent organ instead of dying, because the second covers the next one.
    # Both are tracked here and in engine/, which finding 44 requires: the publisher derives the
    # public tree from TRACKED files, so an untracked organ the scaffolder demands makes every
    # scaffolded repository uninstallable.
    ".veldo/executor.py",
    ".veldo/runlog.py",
    # THE ESTIMATION LAYER, laid down 2026-08-13 so chapter 13's capability is a CAPABILITY and not a
    # file. Ledger findings 61 and 73 are the two halves of why this list has to be closed: an organ
    # laid down without what IT loads gives the adopter a traceback, and a publisher that withholds a
    # dependency while shipping its dependents does the same thing one layer out. Three reviewers found
    # that deleting the publish exclusions alone would ship files nobody could run, because init laid
    # down NONE of these.
    # THE SET IS THE CLOSURE, NOT THE FOUR MODULES THE BOOK NAMES. The four are estimate, toe_normalize,
    # judgment_load and cost_to_change; the rest are what they load, reported as handover notes by the
    # agents that fixed them and confirmed by the transitive-closure check, which named `plan.py` the
    # moment two organs were added on 2026-08-13 and will name anything still missing here.
    # Every one is tracked in BOTH homes, which finding 44 requires: the publisher derives the public
    # tree from TRACKED files, so an untracked organ the scaffolder demands makes every scaffolded
    # repository uninstallable.
    ".veldo/estimate.py",
    ".veldo/toe_normalize.py",
    ".veldo/judgment_load.py",
    ".veldo/cost_to_change.py",
    ".veldo/sizing_pass.py",
    ".veldo/toe_analogy.py",
    ".veldo/toe_budget.py",
    ".veldo/toe_reconcile.py",
    # Loaded BY the above rather than part of the layer's own surface. claim.py arrived in this list
    # because finding 71's fix routes every estimate path through the ledger's one id rule.
    ".veldo/claim.py",
    ".veldo/toe_corpus.py",
    ".veldo/spend.py",
    # FOUND BY RUNNING, NOT BY READING, and that distinction is the whole lesson of 2026-08-13. The
    # transitive-closure check passed with these absent, because it follows the load calls it can SEE,
    # and `toe_reconcile` reaches these two at command time. So the check was green while
    # `toe_reconcile report` still exited 1 in a freshly installed pack on
    # `FileNotFoundError: .veldo/metrics.py`. Discovered by installing the pack and running the command
    # in a loop, laying down whatever it asked for next, until it exited 0 - which took two rounds.
    # A GREEN CHECK IS NOT AN INSTALLED PRODUCT. Ledger 61 and 73 are the same lesson from two other
    # angles, and this is the third: the only thing that proves an adopter can run something is running
    # it as the adopter, in the tree the publisher produced.
    ".veldo/metrics.py",
    ".veldo/metrics_event_stream.py",
    # REACHED THROUGH executor.py, and the repository's own transitive closure check caught the
    # omission the moment the two above were added: "every .veldo module reachable from ANY laid
    # script is itself laid". Laying an organ without what IT loads is the same broken install one
    # level down, which is why that check follows the chain rather than naming its links.
    ".veldo/plan.py",
    ".veldo/promises.py",
    ".veldo/declared.py",
    ".veldo/budget_state.py",
    ".veldo/version.py",
    ".veldo/policy.yaml",
    ".veldo/policy_check.py",
    ".veldo/capabilities.yaml",
    "scripts/update_index.py",
    "scripts/secret_inventory.py",
    "scripts/veldo-guard.sh",
    "specs/TEMPLATE.md",
    "specs/TEMPLATE-standing.md",
    "specs/index.md",
    "plans/TEMPLATE.md",
    "plans/STARTER.md",
    "proof/.gitkeep",
    ".claude/settings.json",
    ".github/workflows/veldo-gate.yml",
]

# Directories whose every file is copied (recursively).
_DIRS = [".veldo/examples"]

# VELDO-0045: non-code runtime assets. The canonical copy is the templates' runtime/ directory
# (engine/runtime/ here, runtime/ in a composed pack) and it is laid down under the target's .veldo,
# beside the modules that read it (source, destination). scripts/check_template_sync.sh pairs
# engine/runtime/<name> with .veldo/runtime/<name> by the same rule.
_RUNTIME_ASSETS = [("runtime/langgraph-records.json", ".veldo/runtime/langgraph-records.json")]

# The canonical gate is laid down transformed (see _starter_gate).
_GATE = "scripts/verify.sh"

# Files that must be executable in the scaffolded repository.
_EXECUTABLE = {
    "scripts/verify.sh",
    "scripts/update_index.py",
    "scripts/veldo-guard.sh",
    ".veldo/validate.py",
    ".veldo/policy_check.py",
}

# The substrate that must be present for a repository to be VELDO-ready and for
# its gate to run green. missing_substrate() checks exactly these.
REQUIRED_SUBSTRATE = [
    "scripts/verify.sh",
    "scripts/update_index.py",
    "scripts/secret_inventory.py",
    "scripts/veldo-guard.sh",
    ".veldo/validate.py",
    ".veldo/validate_checks.py",
    # VELDO-0016 AC3: validate_checks loads the contract loader EAGERLY (consumers catch its
    # refusal by name), so a scaffolded repository without it has no validator at all.
    ".veldo/contract_loader.py",
    # The proof-corpus enumeration validate.py loads: a scaffolded repository whose validator
    # cannot import it has no contract stage at all, so it is REQUIRED substrate, not optional.
    # VELDO-0104 (PLAN-0020 W4): the fix-validation record and the rule the proof check applies.
    # validate_checks registers its loader, so a scaffolded repository without it has no proof stage;
    # and it loads the runner by path, which loads the capsule module, so all three travel together.
    ".veldo/fix_validation_record.py",
    ".veldo/git_process.py",
    ".veldo/yamlish.py",
    ".veldo/fix_validation.py",
    ".veldo/capsule.py",
    ".veldo/verdict_corpus.py",
    ".veldo/events.py",
    # VELDO-0051: substrate, because the validator loads the canonical event vocabulary.
    ".veldo/control_event_vocabulary.py",
    ".veldo/arch.py",
    ".veldo/decision.py",
    ".veldo/request.py",
    ".veldo/decision_review.py",
    ".veldo/observability.py",
    ".veldo/secret_inventory.py",
    ".veldo/secret_scan.py",
    ".veldo/shape_review.py",
    ".veldo/security_review.py",
    ".veldo/shape_gate.py",
    ".veldo/tripwire.py",
    ".veldo/tracker.py",
    # VELDO-0012 and VELDO-0011: validate_checks loads both organs, so a scaffolded
    # repository missing them raises FileNotFoundError the first time run_all reaches the
    # check. Derived, not remembered: the suite reads validate_checks for its literal
    # loader paths and reds if either list omits one.
    ".veldo/behavior_floor.py",
    ".veldo/release_contract.py",
    ".veldo/policy.yaml",
    ".veldo/policy_check.py",
    ".veldo/capabilities.yaml",
    ".veldo/examples/spec-example.md",
    "specs/TEMPLATE.md",
    "specs/index.md",
    "plans/STARTER.md",
    "proof/.gitkeep",
    "CLAUDE.md",
    "VELDO.md",
]


def required_substrate():
    """The relative paths a VELDO-ready repository must carry. Pure accessor."""
    return list(REQUIRED_SUBSTRATE)


def missing_substrate(target):
    """The required substrate paths absent under target, in declared order."""
    target = Path(target)
    return [rel for rel in REQUIRED_SUBSTRATE if not (target / rel).exists()]


# THE INSTALL STAMP (VELDO-0009). GENERATED, never copied from a template, which is deliberate: a
# template would have to be tracked and published, and this file's whole content is a fact about THIS
# install. It records the version the substrate was laid from, so substrate drift has a detector - an
# adopter running an old base against new documentation currently has no way to notice.
#
# CREATE-ONLY, like everything else here: a re-run never overwrites it, so the stamp keeps saying what
# the FIRST install was rather than being quietly rewritten by a later re-run that laid nothing.
STAMP = ".veldo/installed.json"
STAMP_SCHEMA = "veldo.installed/v1"


# WHERE A VERSION LIVES DEPENDS ON THE SHAPE, and there are three real ones. In THIS repository the
# templates are engine/ and the manifest is at the repository root above it. In a composed Claude pack
# it is .claude-plugin/plugin.json inside the pack. In the other composed packs it is plugin.json at
# the pack root. Declared as a list of candidates rather than assumed, because assuming ONE shape is
# precisely the mistake that made 1.0 uninstallable.
_VERSION_CANDIDATES = (".claude-plugin/marketplace.json", ".claude-plugin/plugin.json",
                       "plugin.json")

# THE ONE DEFINITION OF WHAT A VERSION LOOKS LIKE, AND OF WHOSE VERSION THIS IS, borrowed from the
# reader rather than copied here. Two enumerations of one rule diverge, and .veldo/version.py already
# owns both rules - _version_shaped() and PLUGIN_NAME - and is laid down beside this file in every
# scaffolded tree and composed into every published pack. If it is not there, this module writes NO
# STAMP and says why, because an unchecked stamp is exactly the guess AC3 forbids.
_VERSION_READER = None


def _version_reader():
    """The sibling version reader, or None. Loaded once and lazily: this module is also imported for
    its substrate lists alone, and an import that can fail must not fail then."""
    global _VERSION_READER
    if _VERSION_READER is None:
        p = Path(__file__).resolve().parent / "version.py"
        _VERSION_READER = False
        if p.is_file():
            try:
                spec = importlib.util.spec_from_file_location("veldo_version_for_stamp", p)
                mod = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(mod)
                _VERSION_READER = mod
            except Exception:            # noqa: BLE001 - a broken sibling stands the stamp down
                _VERSION_READER = False
    return _VERSION_READER or None


def _version_in(root, plugin_name, shaped):
    """The version a manifest at this root declares FOR THIS PROJECT, or None.

    BY IDENTITY, NEVER BY POSITION. This read took plugins[0], which is the defect .veldo/version.py
    was fixed for and which survived here: independent review measured a parent marketplace listing
    ANOTHER plugin first stamping that plugin's version as this install's - a fact nobody declared
    about veldo, and precisely what AC3 means by a stamp that guesses.

    AND A STRING IS NOT A VERSION. Any non-empty string used to pass, so a manifest declaring "   "
    produced a stamp whose version was "   ", which installed_version returned as a VERSION with no
    cause and drift() then reported as substrate drift against the real number. The shape rule is the
    reader's own, not a second copy of it."""
    for rel in _VERSION_CANDIDATES:
        p = Path(root) / rel
        if not p.is_file():
            continue
        try:
            data = json.loads(p.read_text())
        except (OSError, ValueError):
            continue
        if not isinstance(data, dict):
            continue
        plugins = data.get("plugins")
        if isinstance(plugins, list):
            # A MARKETPLACE HOSTS A LIST, so the entry is matched by NAME. No fall-through to the top
            # level afterwards: a "version" sitting beside the list is a schema version and answering
            # with it would be the positional read wearing a different hat.
            for e in plugins:
                if isinstance(e, dict) and e.get("name") == plugin_name and shaped(e.get("version")):
                    return e["version"]
            continue
        if data.get("name") == plugin_name and shaped(data.get("version")):
            return data["version"]
    return None


def _template_version(templates):
    """The version these templates were laid from, or None. NEVER GUESSED: a stamp claiming a version
    nobody declared would be worse than no stamp, because it makes a drift detector confidently
    wrong. Looks at the templates root, then at its PARENT, which is what covers this repository -
    the templates are engine/ and the manifest sits above it."""
    reader = _version_reader()
    if reader is None:
        return None
    t = Path(templates)
    return (_version_in(t, reader.PLUGIN_NAME, reader._version_shaped)
            or _version_in(t.parent, reader.PLUGIN_NAME, reader._version_shaped))


def _stamp_stand_down(templates):
    """Why no stamp can be written from these templates, or None.

    THE STAND-DOWN IS REPORTED, NEVER SILENT. Ledger finding 64: a stand-down recorded in a report dict
    that nothing prints is a measurement an operator cannot tell from a zero. Independent review
    measured the consequence here - five of the seven supported packs (aider, codex, copilot, cursor,
    opencode) carry no manifest at any shape _VERSION_CANDIDATES searches, so their adopters got no
    record, read "substrate complete" with no word that it had not been laid, and their tree then
    answered UNSTAMPED with a reason that was false about an install made minutes earlier. SAYING SO at
    install time is the half that belongs here; a pack that declares nothing still cannot be stamped,
    and the reason names the shapes that were looked for so the gap is legible rather than mysterious."""
    if _version_reader() is None:
        return ("no install record was laid: the version rules live in .veldo/version.py and it is not "
                "beside this scaffolder, so a stamp here would be unchecked rather than measured")
    if _template_version(templates) is None:
        return ("no install record was laid: these templates (%s) declare no version for this project "
                "at any of the shapes searched (%s, or the same in the templates' parent), so a stamp "
                "would be a guess. Substrate drift cannot be detected in this repository until one of "
                "them declares it" % (templates, ", ".join(_VERSION_CANDIDATES)))
    return None


def _write_stamp(templates, target, created, skipped, now=None):
    """(stamp, stand_down): record what this install was laid from.

    Returns (None, None) when a stamp is already there - create-only, like everything else here - and
    (None, reason) when the templates declare no version, in which case NOTHING is written, because an
    unstamped install is an honest state and a stamp saying 'unknown' is a fact nobody can act on. The
    REASON travels back to the caller so it can be printed: a stand-down nobody prints is silence."""
    dest = Path(target) / STAMP
    if dest.exists():
        skipped.append(STAMP)
        return None, None
    version = _template_version(templates)
    if version is None:
        return None, _stamp_stand_down(templates)
    stamp = {"schema": STAMP_SCHEMA, "version": version,
             "installed_at": now or datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
             "laid_from": str(templates)}
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(json.dumps(stamp, indent=1, sort_keys=True) + "\n")
    created.append(STAMP)
    return stamp, None


def _starter_gate(text):
    """Turn the template gate into a starter gate that is green on an empty
    repository. The template leaves the unit and dependency_audit slots blank
    on purpose so an unconfigured gate stays RED until a human declares them.
    A fresh repository has neither a unit suite nor a dependency yet, so the
    honest declaration is na with a reason and a prompt to set required: later.
    If a blank slot is missing the template has drifted; fail loud rather than
    lay a gate that is silently red."""
    subs = [
        ('CHECK_unit=""',
         'CHECK_unit="na:no unit suite adopted yet; set required:<command> when the first test lands"'),
        ('CHECK_dependency_audit=""',
         'CHECK_dependency_audit="na:no third-party dependencies yet; set required:<command> when the first is added"'),
    ]
    for old, new in subs:
        if old in text:
            text = text.replace(old, new)
            continue
        # A SLOT ALREADY CARRYING THE STARTER DECLARATION IS NOT DRIFT. The published template
        # ships these slots pre-filled with exactly the value this function would write, so
        # demanding the blank form made init fail on the one artifact an adopter actually
        # receives while succeeding on the source repository nobody installs. Idempotent, for
        # the same reason nothing else here overwrites a file that already exists.
        if new in text:
            continue
        raise ScaffoldError(
            f"gate template drift: slot {old!r} is neither blank nor already the starter "
            "declaration; the starter gate would not be green")
    return text


def _files_in(templates_dir, rel_dir):
    base = templates_dir / rel_dir
    if not base.is_dir():
        return []
    out = []
    for p in sorted(base.rglob("*")):
        if p.is_file():
            out.append(str(p.relative_to(templates_dir)).replace(os.sep, "/"))
    return out


def _lay(src, dst, rel, created, skipped, transform=None):
    """Lay one file, never overwriting. Returns nothing; records the outcome."""
    if dst.exists():
        skipped.append(rel)
        return
    dst.parent.mkdir(parents=True, exist_ok=True)
    if transform is not None:
        dst.write_text(transform(src.read_text()))
    else:
        dst.write_bytes(src.read_bytes())
    if rel in _EXECUTABLE:
        os.chmod(dst, 0o755)
    created.append(rel)


def _regenerate_index(target):
    """Regenerate the derived spec index by invoking the target's OWN
    generator, so index derivation is never reimplemented here. The index is
    the one derived file; regenerating it to identical content is not an
    overwrite of authored work. Fail loud if the generator errors."""
    gen = target / "scripts" / "update_index.py"
    if not gen.exists():
        raise ScaffoldError("update_index.py absent from the scaffold; cannot refresh the index")
    res = subprocess.run([sys.executable, str(gen)],
                         capture_output=True, text=True)
    if res.returncode != 0:
        raise ScaffoldError(
            "index generation failed in the scaffolded repository: "
            + (res.stderr.strip() or res.stdout.strip()))


def scaffold(target, templates=None):
    """Lay the VELDO substrate into target from the plugin templates.

    Idempotent: an existing file is never overwritten, so a second run over the
    same directory changes no authored file. Returns a report dict with the
    created and skipped relative paths and the resolved target path.
    """
    target = Path(target)
    templates = Path(templates) if templates is not None else DEFAULT_TEMPLATES
    if not (templates / _GATE).exists():
        raise ScaffoldError(f"templates not found or incomplete at {templates}")
    target.mkdir(parents=True, exist_ok=True)

    created, skipped = [], []

    # the canonical gate, transformed into a starter gate that is green empty
    _lay(templates / _GATE, target / _GATE, _GATE, created, skipped, transform=_starter_gate)

    # the individual substrate files, copied byte for byte
    for rel in _FILES:
        src = templates / rel
        if not src.exists():
            raise ScaffoldError(f"template missing: {rel}")
        _lay(src, target / rel, rel, created, skipped)

    # whole directories (examples), copied byte for byte
    for rel_dir in _DIRS:
        for rel in _files_in(templates, rel_dir):
            _lay(templates / rel, target / rel, rel, created, skipped)

    # the non-code runtime assets, copied byte for byte under .veldo
    for src_rel, dst_rel in _RUNTIME_ASSETS:
        src = templates / src_rel
        if not src.exists():
            raise ScaffoldError(f"template missing: {src_rel}")
        _lay(src, target / dst_rel, dst_rel, created, skipped)

    # the derived index reflects the scaffolded specs and starter plan
    _regenerate_index(target)

    # the install stamp: what this substrate was laid from, so drift has a detector (VELDO-0009)
    stamp, stand_down = _write_stamp(templates, target, created, skipped)

    return {"target": str(target), "created": created, "skipped": skipped, "stamp": stamp,
            "stamp_stand_down": stand_down}


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if len(argv) != 1:
        print(__doc__)
        return 2
    try:
        report = scaffold(argv[0])
    except ScaffoldError as e:
        print(f"veldo init: FAIL: {e}")
        return 1
    print(f"veldo init: scaffolded {report['target']}")
    print(f"  created {len(report['created'])} file(s), skipped {len(report['skipped'])} existing")
    # THE STAND-DOWN LEADS THE REST OF THE REPORT rather than being left out of it. An install that
    # laid no record and said nothing about it is how five of the seven packs shipped adopters a tree
    # whose own drift detector then blamed an install nobody made.
    if report.get("stamp_stand_down"):
        print(f"  {report['stamp_stand_down']}")
    missing = missing_substrate(report["target"])
    if missing:
        print(f"  WARNING substrate incomplete: {', '.join(missing)}")
        return 1
    print("  substrate complete; run ./scripts/verify.sh to confirm the gate is green")
    return 0


if __name__ == "__main__":
    sys.exit(main())
