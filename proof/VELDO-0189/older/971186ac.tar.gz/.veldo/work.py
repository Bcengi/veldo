#!/usr/bin/env python3
"""veldo work: the fleet worker loop.

A worker joins the pool with a set of capabilities and an optional scope and then, with
no central coordinator, repeatedly:

  1. asks the frontier what is claimable for it (WARP-0702),
  2. atomically claims the next unit it can (WARP-0701),
  3. DISPATCHES it - a build or a review - and
  4. releases the claim, then loops, stopping when nothing is claimable (drained).

The loop's control logic (claim, dispatch, release, drain) is mechanical and gate-tested
here over a fake dispatcher with no live agent. The DISPATCH itself is delegated: building
a spec and reviewing one are agent work, so a real Dispatcher hands them to the agent (via
the executor / veldo run for a build, a fresh-context reviewer for a review) and makes the
outcome durable (a landed build flips the spec to shipped, so it leaves the frontier). The
loop holds the claim across the dispatch so no other worker takes the same unit, and always
releases after, so a failed unit becomes claimable again for a retry. Because claimable() is
a snapshot and the claim gates ownership only (not done-ness), the loop re-checks after each
claim that the unit is still the work it saw (claim-then-recheck) and releases + skips it if
another worker finished it in the claim-time window, so two workers never dispatch the same
unit. Pure stdlib control logic; Unix-only via the claim ledger. This is the loop only; the
serialized lander is Y4.

VELDO-0135: enrolled work is offered from its floor record and rechecked against it after the claim
(frontier.floor_station), never against the spec file's status line, which the floor authority's
dispatcher does not write. Each dispatched enrolled offer is observed joined to the dispatch it led to."""
import importlib.util
import os
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def _load(name, rel):
    spec = importlib.util.spec_from_file_location(name, ROOT / rel)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


FR = _load("veldo_frontier_wk", ".veldo/frontier.py")
CL = _load("veldo_claim_wk", ".veldo/claim.py")
# VELDO-0052: the shared floor eligibility service (selection, claim and every later station).
EL = _load("veldo_eligibility_wk", ".veldo/control_eligibility.py")


class Dispatcher:
    """The seam a worker dispatches a claimed unit through. A real dispatcher delegates to
    the agent: a build unit is built and landed (the executor / veldo run), a review unit is
    reviewed (a fresh-context reviewer), and the durable outcome (spec shipped, or verdict
    recorded) is what removes the unit from the frontier. Returns {ok: bool, ...}."""

    def dispatch(self, unit):
        raise NotImplementedError(
            "inject a Dispatcher; building and reviewing are delegated agent steps")


# The bounded dispatch RECEIPT (WARP-0909). A long-running session that drives many specs
# in one loop (an autonomous or multi-spec run) must stay a THIN DISPATCHER: it hands each
# spec's build and review to a FRESH sub-context and keeps only a small receipt per spec,
# never the sub-context's transcript. Its memory then stays flat across any number of specs
# instead of growing as the sum of all of them. On 2026-07-19 an orchestrator that drove
# spec after spec INLINE, accumulating every build context plus every review transcript in
# one process, reached ~17.8 GB and was OOM-killed. This is the mechanical half of that rule:
# the exact bounded value the loop retains per spec.

# The allowlist of small summary fields a receipt may carry. Everything else, a full nested
# executor result, a build transcript, file contents, a fat land record, full review
# reasoning, is DROPPED. Failing closed (an allowlist, never a denylist) is deliberate: an
# unknown field a future dispatch adds cannot silently smuggle unbounded content through.
RECEIPT_FIELDS = ("spec", "kind", "ok", "status", "verdict", "commit",
                  "proof_digest", "gate", "halted_at", "reason")


def dispatch_receipt(outcome, fields=RECEIPT_FIELDS):
    """Project a dispatch outcome to its BOUNDED receipt: a new dict carrying only the
    allowlisted summary fields that are present in the outcome, and nothing else. Pure - it
    reads one mapping and copies scalars, no I/O. This is the value a thin orchestrator keeps
    per spec so its footprint stays flat across a long loop (the 2026-07-19 OOM cure). It
    fails CLOSED: an outcome that also carries a full nested `result`, a `transcript`, `land`
    details, file contents, or any other bulky field has those DROPPED, because only
    allowlisted keys survive. The mechanical dispatch (dispatch.py) may return such fields in
    its own single-call outcome; the receipt is the bounded thing the LOOP retains, so
    orchestrator memory cannot grow without bound even when a dispatch outcome does."""
    src = outcome or {}
    return {k: src[k] for k in fields if k in src}


class WorkLoop:
    """The claim/dispatch/release/drain loop. Control logic only; dispatch is delegated."""

    def __init__(self, worker_id, capabilities, dispatcher, scope=None,
                 repo_root=None, claims_root=None, eligibility=None):
        self.worker_id = worker_id
        # VELDO-0052: the shared eligibility Gate. With the floor enabled (a Gate, or an enrolled
        # repository, which stops by name without one) the claim station decides against the
        # selection ticket before the claim, and again after it, so a consumed input that moved
        # in the claim-time window is a named refusal and the claim is released.
        self.eligibility = eligibility
        self.caps = list(capabilities or [])
        self.dispatcher = dispatcher
        self.scope = scope
        self.repo_root = repo_root
        self.claims_root = claims_root
        # (unit, station) pairs this worker dispatched and that failed: it releases them (for a
        # human or another worker or a later retry) but does NOT re-claim them at that station
        # itself, so one worker never hot-loops its own failing unit. Keyed by the station too, so a
        # unit whose failed review sent it back to build is still rebuilt in the same run.
        self._failed = set()

    def _still_claimable(self, unit, gate=None):
        """After an atomic claim, re-check the unit is still the work we saw on the frontier.
        claimable() is a snapshot and the claim gates OWNERSHIP only, not done-ness, so between
        the snapshot and our claim another worker may have finished the unit. Its deps only ever
        go ready -> shipped (monotonic) and capability/scope do not change, so the only thing
        that can regress in that window is the spec's own status: a build unit must still be
        ready, a review unit must still be in review. If not, another worker finished it.

        VELDO-0135: for enrolled work the status line never moves, so the recheck reads the unit's
        floor record through the frontier's own floor reader, and the unit is still claimable only
        while that record keeps it at the station it was offered for: a unit handed off, landed,
        returned or waiting on an open finding since the snapshot is released, never dispatched."""
        entry = FR.floor_station(unit["spec"], self.repo_root, gate if gate is not None else self.eligibility)
        if entry is not None:
            if entry["station"] == unit.get("kind"):
                return True
            # The record moved on since the offer and took the unit away from the offered station.
            reason = "stale_version:floor_record"
            self._observe_floor(gate, unit, "floor_recheck", outcome="withheld", station=entry["station"],
                                version=entry["version"], state=entry["state"], reason=reason,
                                taxonomy=FR.floor_taxonomy(reason), detail=[entry["reason"]] if entry["reason"] else [])
            return False
        expected = "review" if unit.get("kind") == "review" else "ready"
        return FR.current_status(unit["spec"], self.repo_root) == expected

    @staticmethod
    def _observe_floor(gate, unit, operation, **fields):
        """One observation of an enrolled unit through the Gate's sink, joined to its offer by id."""
        if gate is None:
            return
        offered = unit.get("floor") or {}
        gate.observe(dict({"schema": FR.FLOOR_OFFER_SCHEMA, "operation": operation, "domain_uuid": gate.domain_uuid,
                           "repository_uuid": gate.repository_uuid, "unit": unit.get("spec"),
                           "offer": offered.get("offer"), "offered_station": unit.get("kind"),
                           "offered_version": offered.get("version")}, **fields))

    def _observe_dispatch(self, unit, result):
        """VELDO-0135: join an enrolled offer to the dispatch it led to, by identity: the offer's id, the
        record version it was offered from, the version the dispatch left, and the VELDO-0039 dispatch
        each new build or review the authority recorded names."""
        gate = EL.gate_for(self.repo_root or FR.ROOT, self.eligibility)
        offered = unit.get("floor") or {}
        after = FR.floor_station(unit["spec"], self.repo_root, gate) or {}
        if unit.get("kind") == "build":
            led = [after.get("build_dispatch")] if after.get("build_dispatch") not in (None, offered.get("build_dispatch")) else []
        else:
            led = list(after.get("review_dispatches") or [])[len(offered.get("review_dispatches") or []):]
        self._observe_floor(gate, unit, "floor_dispatch", outcome="dispatched", station=unit.get("kind"),
                            version=after.get("version"), state=after.get("state"), dispatches=led,
                            ok=bool((result or {}).get("ok")), reason=(result or {}).get("reason"))

    def _claim_next(self):
        """Claim the next claimable unit this worker can take, or None if none claimable.
        Skips units this worker already failed, and tries each candidate until one claim
        succeeds (another worker may have raced us). After a successful claim, re-checks the
        unit is still claimable (claim-then-recheck) and releases + skips it if another worker
        finished it in the claim-time window, so two workers never dispatch the same unit."""
        gate = EL.gate_for(self.repo_root or FR.ROOT, self.eligibility)
        for u in FR.claimable(worker_caps=self.caps, scope=self.scope,
                              repo_root=self.repo_root, claims_root=self.claims_root,
                              eligibility=gate):
            if (u["spec"], u["kind"]) in self._failed:
                continue
            if gate is not None and not gate.decide("claim", u["spec"], ticket=u.get("eligibility"))["eligible"]:
                continue
            ok, _reason = CL.claim(u["spec"], self.worker_id, self.caps,
                                   u.get("requires"), root=self.claims_root)
            if not ok:
                continue
            if not self._still_claimable(u, gate):
                CL.release(u["spec"], self.worker_id, root=self.claims_root)
                continue
            if gate is not None:
                # CLAIM-THEN-RECHECK against every consumed input, not the status line alone.
                after = gate.decide("claim", u["spec"], ticket=u.get("eligibility"))
                if not after["eligible"]:
                    CL.release(u["spec"], self.worker_id, root=self.claims_root)
                    continue
                # The authority client (VELDO-0031) retains the generation it was granted; the
                # file ledger has none, and then ownership alone is decided at later stations.
                u = dict(u, eligibility=after, holder=self.worker_id,
                         generation=(getattr(self.claims_root, "generations", None) or {}).get(u["spec"]))
            return u
        return None

    def step(self):
        """Claim the next unit, dispatch it, and release the claim. Returns the outcome
        {unit, result}, or None if nothing is claimable (drained). The claim is held across
        the dispatch and always released after, even if the dispatch raises."""
        unit = self._claim_next()
        if unit is None:
            return None
        try:
            result = self.dispatcher.dispatch(unit)
        except Exception as e:  # a crashed dispatch is a failed unit, not a stuck claim
            result = {"ok": False, "error": repr(e)}
        finally:
            CL.release(unit["spec"], self.worker_id, root=self.claims_root)
        if unit.get("floor"):
            self._observe_dispatch(unit, result)
        if not (result or {}).get("ok"):
            # released above for a human / another worker / a later retry, but this worker
            # will not re-claim it, so it moves on to other work instead of hot-looping.
            self._failed.add((unit["spec"], unit["kind"]))
        return {"unit": unit, "result": result}

    def run(self, max_units=10000):
        """Run steps until drained (nothing claimable) or max_units, and return the outcomes.
        max_units is a runaway backstop, not the normal stop - the normal stop is drain."""
        outcomes = []
        for _ in range(max_units):
            out = self.step()
            if out is None:
                break
            outcomes.append(out)
        return outcomes


def veldo_work(dispatcher, worker_id=None, capabilities=None, scope=None,
              repo_root=None, claims_root=None, max_units=10000, eligibility=None):
    """Front door: allocate a worker id, run the loop with the given dispatcher, return the
    outcomes. A real caller injects a Dispatcher that delegates build/review to the agent."""
    wid = worker_id or ("worker-" + uuid.uuid4().hex[:12])
    loop = WorkLoop(wid, capabilities, dispatcher, scope=scope,
                    repo_root=repo_root, claims_root=claims_root, eligibility=eligibility)
    return {"worker_id": wid, "outcomes": loop.run(max_units=max_units)}
