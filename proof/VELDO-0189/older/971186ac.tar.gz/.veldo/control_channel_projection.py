"""Telegram projection of the assignment inbox with durable message correlation (VELDO-0064).

WHAT THIS MODULE IS. The ordinary outbound Telegram projection of pending person assignments.
For every valid pending inbox entry that has no projection at its current request version, it
renders the presentation bytes from the inbox brief and keeps one `channel_projection` entity
per (assignment, request version). The record binds the assignment id, the entity version and the
request version presented, and the digest of the exact bytes. A changed request version is a new
presentation and a new message.

INTENT BEFORE SEND. The record is committed as a `pending` intent BEFORE the message is sent
through the Telegram Bot API `sendMessage` method, and a second store command completes it with
what the platform returned: its chat identity, its message identity, its date and the text it
stored. If the intent cannot be written, nothing is sent. If the completion cannot be written,
the intent stays `pending`: its outcome is unknown and it is never sent again automatically,
by this run or any later one, whatever projector finds it. Only a definite platform refusal
(`refused`: the platform answered and published nothing) is attempted again, as a new attempt
of the same record. The one reply that proves nothing was published is Telegram's own error
answer: an HTTP 4xx whose body is the Bot API error object (`ok` false, `error_code` equal to
the status). A 5xx, a gateway or proxy page, a malformed status line or an unreadable body may
follow a delivered message, so each is `unknown_outcome` and is never sent again automatically.

EACH OWNER'S OWN CHAT. An assignment is sent to the chat enrolled for ITS owner: a
`channel_enrollment` entity in the control store (`veldo.channel_enrollment/v1`, id
`channel-enrollment:telegram_chat:<principal>`) naming the principal and the numeric Telegram
chat id. The edge holds no chat of its own. An owner with no enrollment is refused as
`no_enrolled_chat`, and an enrollment that is revoked, malformed or names another principal as
`invalid_enrollment`; neither is ever sent to someone else's chat. The intent binds the
enrollment's entity version.

WHAT THE PLATFORM SAID IS WHAT IS KEPT. The chat and message identity recorded are the ones the
platform returned. A platform answer is classified by the store transition that records it, never by
the caller: when the text the platform stored differs from the bytes sent, the message still
exists, so its returned identity and stored text are kept and the record is the named anomaly
`presentation_mismatch` (outcome `anomaly`), not a valid projection and never sent again. The
same holds when the platform says it placed the message in a chat other than the owner's
enrolled chat: the returned chat is recorded as returned and the record is `chat_mismatch`. A transport
or protocol failure after the request may have reached the platform (a lost connection, a
malformed status line, an unreadable body), and so does anything else the edge raises once the
intent is committed: each is recorded as `unknown_outcome` with no message identity and an
observation naming why, so nothing is blindly sent again and one bad reply never stops the
projection of the entries after it. Looking the message up and recovering an unknown or pending
record is Release 2 work.

ONE DECISION MESSAGE WHEN PRESENTATIONS ARE IN USE (VELDO-0065). Whether this projection sends is
decided from the store, never from how it was constructed: when the owner's enrollment says
`presentations: enabled`, or the request has a VELDO-0065 framing (its requester's signed request to
present it) or presentation receipt, it sends no
notice of its own, because the versioned presentation is the one decision message and the owner's
reply to it is what settles. Such an entry is reported as `presented` when a presentation of its
current request version is published, otherwise `awaiting_presentation`. A projection given the
optional `presenter` reports the presenter's own verdict and reason, and its metrics are the
presenter's. A notice this projection sent before presentations were in use is visibly superseded
by the first presentation (a reply that names it), which marks the notice's record superseded.
Every other entry is projected as below.

NOT AUTHORITY. A projection is a proxy of the inbox. Nothing here reads an answer, settles a
request or changes an assignment. Presentation receipts and supersession are VELDO-0065, answer
acquisition and attribution VELDO-0066, edge signing VELDO-0067, activation of the live edge
VELDO-0073. The bot token is supplied by the caller's custody and never logged or stored.
Standard library only.
"""
import hashlib
import http.client
import json
import time
import urllib.error
import urllib.request

SCHEMA = 'veldo.channel_projection/v1'
ENTITY_KIND = 'channel_projection'
OPERATION = 'channel_projection_record'
CHANNEL = 'telegram_chat'
# The outcomes of one record. `pending` is the committed intent before the send completes.
OUTCOMES = ('pending', 'sent', 'anomaly', 'refused', 'unknown_outcome')
# Named anomalies of a published message that is not a valid projection.
ANOMALIES = ('presentation_mismatch', 'chat_mismatch')
# Only a definite refusal, where the platform answered and published nothing, is attempted again.
RETRYABLE = ('refused',)
INTENT_FIELDS = ('schema', 'channel', 'assignment_id', 'assignment_version', 'request_version',
                 'presentation_digest', 'presentation', 'owner', 'enrollment_id', 'enrollment_version',
                 'enrolled_chat')
ENROLLMENT_KIND = 'channel_enrollment'
# The enrollment field that turns presentations on for an owner's chat, and VELDO-0065's receipt kind
# (control_channel_presentation.RECEIPT_KIND; the VELDO-0065 suite binds the two).
PRESENTATIONS_FIELD = 'presentations'
PRESENTATION_KIND = 'channel_presentation'
# VELDO-0065's framing kind (control_channel_presentation.FRAMING_KIND): a framed request is one its
# requester asked to be presented, so the presentation, not a notice, is its decision message.
FRAMING_KIND = 'presentation_framing'


def framing_entity_id(assignment):
    """The id of a request's VELDO-0065 framing (control_channel_presentation.framing_id; the suite
    binds the two). A notice intent pins its absence, so a framing that lands after this projection
    decided to send refuses the intent and nothing is sent beside the presentation."""
    return 'presentation-framing:%s' % assignment
ENROLLMENT_SCHEMA = 'veldo.channel_enrollment/v1'
PLATFORM_FIELDS = ('chat_id', 'message_id', 'date', 'text')
# What a record that is not attempted again reports on a later run.
SETTLED = {'sent': ('already_projected', None), 'pending': ('unknown_outcome', 'incomplete_projection'),
           'unknown_outcome': ('unknown_outcome', 'unknown_outcome')}


# VELDO-0073: the only Bot API origin an edge reaches without an activation gate is a local stand-in
# on the loopback interface, which cannot carry a message to Telegram. Every other exchange asks the
# gate (control_channel_activation.Gate) the edge was given, and an edge given none refuses.
STAND_IN_ORIGIN = 'http://127.0.0.1:'


def is_stand_in(url):
    """True only for exactly http://127.0.0.1:<port>, parsed rather than matched as a prefix, so text such
    as http://127.0.0.1:80@api.telegram.org, which names another host, is not a stand-in."""
    if not isinstance(url, str) or not url.startswith(STAND_IN_ORIGIN):
        return False
    return url[len(STAND_IN_ORIGIN):].rstrip('/').isdigit()


def is_bot_origin(url):
    """A Bot API origin an edge may be built with: a stand-in, or https to a bare host (no credentials,
    port text or path that could name another host)."""
    if is_stand_in(url):
        return True
    if not isinstance(url, str) or not url.startswith('https://'):
        return False
    host = url[len('https://'):].rstrip('/')
    return bool(host) and all(c.isalnum() or c in '.-' for c in host)
# The gate's refusals an edge reports under their own names; anything else it raises is not_activated.
GATE_REFUSALS = ('not_activated', 'edge_stopped', 'stale_configuration', 'stale_key', 'stale_enrollment',
                 'owner_not_current', 'qualification_expired', 'chat_not_enrolled', 'missing_qualification',
                 'fixture_only_evidence', 'presentation_unproven', 'answer_unproven', 'unauthorized_unproven',
                 'settlement_unproven', 'unavailable_service')


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    """Never follow a redirect: a Bot API exchange goes to its configured origin or nowhere. Returning
    None makes urllib raise the 3xx as an HTTPError, a transport failure the caller already classifies."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def bot_opener(*handlers):
    """The one opener every Bot API exchange uses (VELDO-0073): no proxy from the environment and no
    redirect, so a listener at the configured origin cannot hand the request, token and all, to another
    host. `handlers` add the gate's verified https connection."""
    return urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect(), *handlers)


def gated_open(activation, base_url, request, timeout, operation, chat=None):
    """Open one Bot API exchange of `operation` for an installed Telegram entry point (VELDO-0073). With
    no gate only a loopback stand-in is reached; a resolving token alone is never activation, so any
    other origin refuses as not_activated before a byte leaves. With a gate, the gate admits the
    exchange against the current activation record and performs it. A transport failure keeps its own
    type, so the caller classifies it exactly as before; a gate refusal is an EdgeRefused by name."""
    if activation is None:
        if not is_stand_in(base_url):
            raise EdgeRefused('not_activated', 'a Telegram exchange needs an explicit activation record; a token is not one')
        return bot_opener().open(request, timeout=timeout)
    try:
        return activation.open(request, timeout, operation, base_url, chat)
    except (urllib.error.URLError, http.client.HTTPException, OSError, ValueError):
        raise
    except Exception as exc:
        code = getattr(exc, 'code', None)
        raise EdgeRefused(code if code in GATE_REFUSALS else 'not_activated', 'the activation gate refused') from None


def gated_bot(activation, bot_id):
    """Refuse a getMe answer naming another bot than the activated one (VELDO-0073)."""
    if activation is None:
        return
    try:
        activation.bot(bot_id)
    except Exception as exc:
        code = getattr(exc, 'code', None)
        raise EdgeRefused(code if code in GATE_REFUSALS else 'not_activated', 'the activation gate refused') from None


class EdgeRefused(Exception):
    def __init__(self, code, detail=''):
        super().__init__('%s: %s' % (code, detail))
        self.code, self.detail = code, detail


def presentation_digest(body):
    return 'sha256:' + hashlib.sha256(body).hexdigest()


def projection_id(assignment, request_version):
    return 'projection:%s:%s:%d' % (CHANNEL, assignment, request_version)


def enrollment_id(principal):
    return 'channel-enrollment:%s:%s' % (CHANNEL, principal)


def enrollment_problems(kind, data, principal):
    """Why a stored enrollment does not route `principal`'s assignments, by name."""
    if kind != ENROLLMENT_KIND or not isinstance(data, dict):
        return ['the entity is not a channel enrollment']
    problems = []
    if data.get('schema') != ENROLLMENT_SCHEMA or data.get('channel') != CHANNEL:
        problems.append('the enrollment is not a %s %s enrollment' % (ENROLLMENT_SCHEMA, CHANNEL))
    if data.get('principal') != principal:
        problems.append('the enrollment names another principal')
    if type(data.get('chat_id')) is not int:
        problems.append('the enrolled chat is a numeric Telegram chat id')
    if data.get('revoked_at') is not None:
        problems.append('the enrollment is revoked')
    return problems


def render(brief):
    """The exact presentation text for one valid brief: plain text, no markup, no trailing space.
    Owner, scope, deadline and budget are shown as the inbox holds them."""
    c = brief['content']
    budget = ', '.join('%s=%s' % (unit, c['budget'][unit]) for unit in sorted(c['budget']))
    lines = [
        'Veldo needs your %s' % c['kind'].replace('_', ' '),
        'Assignment: %s' % brief['id'],
        'Request version: %d' % c['request_version'],
        'Owner: %s' % c['owner'],
        'Scope: %s' % ', '.join(c['scope']),
        'Deadline: %s' % c['deadline'],
        'Budget: %s' % budget,
        'Subject: %s %s %s' % (c['subject']['kind'], c['subject']['ref'], c['subject']['digest']),
        'Choices: %s' % ' | '.join(c['choices']),
        '',
        ' '.join(c['brief'].split()),
    ]
    return '\n'.join(line.rstrip() for line in lines)


class TelegramEdge:
    """The Bot API sendMessage call. `base_url` is the Bot API origin; `token` comes from the
    caller's secret custody. The edge has no chat of its own: each send names the chat enrolled
    for the owner of what it sends. `timeout` is keyword-only, so a caller still passing one
    configured chat fails loudly instead of setting a timeout. `activation` is the VELDO-0073 gate
    every send asks; without one only a loopback stand-in is reached."""

    def __init__(self, base_url, token, *, timeout=10, activation=None):
        if not is_bot_origin(base_url):
            raise EdgeRefused('invalid_input', 'the Bot API origin is https, or a loopback test endpoint')
        if not isinstance(token, str) or not token:
            raise EdgeRefused('invalid_input', 'a token is required')
        self.base_url, self._token, self.timeout = base_url.rstrip('/'), token, timeout
        self.activation = activation

    def send(self, chat, text):
        if type(chat) is not int:
            raise EdgeRefused('invalid_input', 'a send names a numeric enrolled chat')
        body = json.dumps({'chat_id': chat, 'text': text, 'disable_web_page_preview': True}).encode()
        request = urllib.request.Request('%s/bot%s/sendMessage' % (self.base_url, self._token), data=body,
                                         method='POST', headers={'Content-Type': 'application/json'})
        try:
            with gated_open(self.activation, self.base_url, request, self.timeout, 'sendMessage', chat) as response:
                answer = json.loads(response.read())
        except urllib.error.HTTPError as exc:
            # Only Telegram's own error answer proves that nothing was published: a 4xx whose body
            # is the Bot API error object for that status. A 5xx, a gateway page or any other
            # reply may follow a delivered message, so its outcome is unknown and never re-sent.
            if not 400 <= exc.code < 500:
                raise EdgeRefused('unknown_outcome', 'HTTP %d is not a definite refusal' % exc.code) from None
            if not telegram_refusal(exc, exc.code):
                raise EdgeRefused('unknown_outcome', 'HTTP %d without the Bot API error answer' % exc.code) from None
            raise EdgeRefused('channel_refused', 'HTTP %d' % exc.code) from None
        except (urllib.error.URLError, http.client.HTTPException, OSError, ValueError) as exc:
            # Every transport and protocol failure after the request left: a lost connection, a
            # malformed status line (http.client.BadStatusLine is not an OSError), a truncated or
            # unreadable body. The message may have been published.
            raise EdgeRefused('unknown_outcome', 'no readable platform answer (%s)' % type(exc).__name__) from None
        result = answer.get('result') if isinstance(answer, dict) and answer.get('ok') is True else None
        chat = result.get('chat') if isinstance(result, dict) else None
        if (not isinstance(chat, dict) or type(chat.get('id')) is not int
                or type(result.get('message_id')) is not int or type(result.get('date')) is not int
                or not isinstance(result.get('text'), str)):
            raise EdgeRefused('unknown_outcome', 'platform answer lacks message identity')
        return {'chat_id': chat['id'], 'message_id': result['message_id'], 'date': result['date'],
                'text': result['text']}


def telegram_error_answer(reply, status):
    """The Bot API's own error answer for `status` carried by an HTTP error reply (a JSON object with
    `ok` false and `error_code` equal to the status), or None. An unreadable body is None."""
    try:
        answer = json.loads(reply.read())
    except (http.client.HTTPException, OSError, ValueError):
        return None
    ok = isinstance(answer, dict) and answer.get('ok') is False and answer.get('error_code') == status
    return answer if ok else None


def telegram_refusal(reply, status):
    """Whether an HTTP error reply is the Bot API's own error answer for `status`."""
    return telegram_error_answer(reply, status) is not None


def anomalies(record, platform):
    """The named anomalies of one platform answer against the intent it completes."""
    found = []
    if platform['text'].encode('utf-8') != record['presentation'].encode('utf-8'):
        found.append('presentation_mismatch')
    if platform['chat_id'] != record['enrolled_chat']:
        found.append('chat_mismatch')
    return found


def _record_transition(params, before):
    """The two registered phases of one record. `intent` creates the record, or starts a new
    attempt of a refused one, as `pending`. `complete` finishes that pending attempt from the
    platform's answer: a definite refusal, no answer at all (unknown), or the returned identity."""
    pid, phase = params.get('projection_id'), params.get('phase')
    if not isinstance(pid, str) or phase not in ('intent', 'complete'):
        raise ValueError('a projection record names its id and phase')
    current = before.get(pid, {}).get('data')
    if phase == 'intent':
        record = params.get('record')
        if not isinstance(record, dict) or set(record) != set(INTENT_FIELDS):
            raise ValueError('an intent carries exactly the presentation it binds')
        if current is not None and current.get('outcome') not in RETRYABLE:
            raise ValueError('only a definite refusal is attempted again')
        data = dict(record, attempt=current['attempt'] + 1 if current else 1, outcome='pending', chat_id=None,
                    message_id=None, platform_date=None, platform_text=None, refusal=None, anomalies=[])
        return {pid: {'kind': ENTITY_KIND, 'data': data}}
    if current is None or current.get('outcome') != 'pending' or current.get('attempt') != params.get('attempt'):
        raise ValueError('a completion finishes the pending attempt it names')
    platform, refusal = params.get('platform'), params.get('refusal')
    data = dict(current)
    if refusal is not None:
        if not isinstance(refusal, str) or platform is not None:
            raise ValueError('a refusal names its code and carries no platform answer')
        data.update(outcome='refused', refusal=refusal)
    elif platform is None:
        data.update(outcome='unknown_outcome')
    else:
        if (not isinstance(platform, dict) or set(platform) != set(PLATFORM_FIELDS)
                or not all(type(platform[k]) is int for k in ('chat_id', 'message_id', 'date'))
                or not isinstance(platform['text'], str)):
            raise ValueError('a platform answer carries its chat, message, date and text')
        found = anomalies(data, platform)
        data.update(outcome='anomaly' if found else 'sent', chat_id=platform['chat_id'],
                    message_id=platform['message_id'], platform_date=platform['date'],
                    platform_text=platform['text'], anomalies=found)
    return {pid: {'kind': ENTITY_KIND, 'data': data}}


class Projection:
    """Projects one inbox to one Telegram edge and records correlation through the store."""

    def __init__(self, store, inbox, edge, conn, journal_signer, sign, authority_generation=1, clock=time.time, *,
                 presenter=None):
        self.store, self.inbox, self.edge, self.conn = store, inbox, edge, conn
        self.presenter = presenter
        self.journal_signer, self.sign = journal_signer, sign
        self.authority_generation, self.clock = authority_generation, clock
        self.observations = []
        self.counts = {'accepted': 0, 'refused': 0}
        self._serial = 0

        def transition(params, before):
            try:
                return _record_transition(params, before)
            except ValueError as exc:
                raise store.StoreRefused('invalid_input', str(exc))
        conn.command_registry[OPERATION] = {'transition': transition,
                                            'writes': ('entities', 'journal', 'commands', 'nonces')}

    def _result(self, assignment, versions, outcome, reason, **extra):
        accepted = outcome in ('sent', 'already_projected', 'presented')
        self.counts['accepted' if accepted else 'refused'] += 1
        self.observations.append(dict(self.inbox.ids, operation='project', channel=CHANNEL,
                                      assignment_id=assignment, accepted_versions=versions,
                                      outcome=outcome, reason=reason, **extra))
        result = dict({'assignment_id': assignment, 'outcome': outcome}, **extra)
        if reason is not None:
            result['reason'] = reason
        return result

    def record(self, pid):
        row = self.conn.execute('SELECT version, data FROM entities WHERE id=? AND kind=?',
                                (pid, ENTITY_KIND)).fetchone()
        return None if row is None else dict(json.loads(row[1]), entity_version=row[0])

    def correlation(self, assignment):
        """The projection records of one assignment, by request version."""
        rows = self.conn.execute('SELECT data FROM entities WHERE kind=? ORDER BY id', (ENTITY_KIND,)).fetchall()
        records = [json.loads(r[0]) for r in rows]
        return {r['request_version']: r for r in records if r.get('assignment_id') == assignment}

    def _commit(self, params, expected):
        """One store command of one phase; returns the record it committed."""
        self._serial += 1
        pid = params['projection_id']
        command_id = '%s:%s:%s:%.6f:%d' % (OPERATION, params['phase'], pid, self.clock(), self._serial)
        command = dict(command_id=command_id, principal=self.journal_signer, operation=OPERATION,
                       parameters=params, expected_versions=expected, artifact_digests=[], nonce=command_id)
        self.store.execute(self.conn, command, self.journal_signer, self.sign, self.authority_generation)
        return self.record(pid)

    def _enrollment(self, owner):
        """(refusal, enrollment): the owner's own enrolled chat, or the named reason there is none."""
        row = self.conn.execute('SELECT kind, version, data FROM entities WHERE id=?', (enrollment_id(owner),)).fetchone()
        if row is None:
            return 'no_enrolled_chat', None
        data = json.loads(row[2])
        if enrollment_problems(row[0], data, owner):
            return 'invalid_enrollment', None
        return None, {'id': enrollment_id(owner), 'version': row[1], 'chat': data['chat_id']}

    def _send(self, chat, text):
        """What the platform said, as the completion parameters of the pending attempt, with
        `detail` naming why an outcome is unknown. The intent is already committed, so whatever the
        edge raises is an unknown outcome of this attempt: it is completed and observed, never sent
        again, and never stops the projection of the entries after it."""
        try:
            sent = self.edge.send(chat, text)
        except EdgeRefused as exc:
            unknown = exc.code == 'unknown_outcome'
            return {'platform': None, 'refusal': None if unknown else exc.code, 'detail': exc.detail if unknown else None}
        except Exception as exc:
            return {'platform': None, 'refusal': None, 'detail': 'the edge raised %s' % type(exc).__name__}
        return {'platform': sent, 'refusal': None, 'detail': None}

    def _project(self, entry):
        aid = entry['id']
        pid = projection_id(aid, entry['request_version'])
        versions = {aid: entry['version']}
        existing = self.record(pid)
        if existing is not None and existing['outcome'] not in RETRYABLE:
            outcome, reason = SETTLED.get(existing['outcome'], ('anomaly', None))
            if outcome == 'anomaly':
                reason = ','.join(existing['anomalies'])
            return self._result(aid, versions, outcome, reason, projection_id=pid)
        brief = self.inbox.brief(aid)
        if not brief['valid'] or brief['version'] != entry['version']:
            return self._result(aid, versions, 'refused', 'stale_subject')
        refusal, enrollment = self._enrollment(brief['content']['owner'])
        if refusal:
            return self._result(aid, versions, 'refused', refusal)
        versions[enrollment['id']] = enrollment['version']
        versions[framing_entity_id(aid)] = 0  # decided with the request not framed: pinned as absent
        text = render(brief)
        record = dict(schema=SCHEMA, channel=CHANNEL, assignment_id=aid, assignment_version=entry['version'],
                      request_version=entry['request_version'], presentation_digest=presentation_digest(text.encode('utf-8')),
                      presentation=text, owner=brief['content']['owner'], enrollment_id=enrollment['id'],
                      enrollment_version=enrollment['version'], enrolled_chat=enrollment['chat'])
        expected = dict(versions, **{pid: existing['entity_version'] if existing else 0})
        try:
            intent = self._commit(dict(phase='intent', projection_id=pid, record=record), expected)
            completion = self._send(enrollment['chat'], text)
        except self.store.StoreRefused as exc:
            return self._result(aid, versions, 'refused', exc.code)  # no intent, so nothing was sent
        detail = completion.pop('detail')
        try:
            done = self._commit(dict(phase='complete', projection_id=pid, attempt=intent['attempt'], **completion),
                                {pid: intent['entity_version']})
        except self.store.StoreRefused as exc:
            # The intent stays pending: the outcome is unknown and is never sent again. What the
            # platform answered is reported here so it is not silently lost.
            platform = completion['platform'] or {}
            return self._result(aid, versions, 'unknown_outcome', exc.code, projection_id=pid,
                                platform={k: platform.get(k) for k in ('chat_id', 'message_id', 'date')})
        if done['outcome'] == 'unknown_outcome':
            return self._result(aid, versions, 'unknown_outcome', 'unknown_outcome', projection_id=pid, detail=detail)
        reason = ','.join(done['anomalies']) if done['outcome'] == 'anomaly' else done['refusal']
        return self._result(aid, versions, done['outcome'], reason, projection_id=pid)

    def _of_request(self, kind, request):
        return [d for d in (json.loads(r[0]) for r in self.conn.execute('SELECT data FROM entities WHERE kind=?', (kind,)))
                if d.get('request_id') == request]

    def _presentations(self, entry):
        """The presentation receipts of this entry's request, or None when presentations are not in
        use for it: not enabled on its owner's enrollment, and the request neither framed nor presented."""
        mine = self._of_request(PRESENTATION_KIND, entry['id'])
        framed = bool(self._of_request(FRAMING_KIND, entry['id']))
        row = self.conn.execute('SELECT data FROM entities WHERE id=? AND kind=?',
                                (enrollment_id(entry['owner']), ENROLLMENT_KIND)).fetchone()
        enabled = row is not None and json.loads(row[0]).get(PRESENTATIONS_FIELD) == 'enabled'
        in_use = enabled or framed or bool(mine)
        return mine if in_use else None

    def _presented(self, entry, receipts):
        """Presentations are in use for this entry: nothing is sent here, the presentation is the message."""
        if self.presenter is not None:
            refusal, record, _ = self.presenter.compose(entry['id'])
            outcome = 'presented' if refusal is None and record is None else 'awaiting_presentation'
            return self._result(entry['id'], {entry['id']: entry['version']}, outcome, refusal)
        shown = any(r.get('outcome') == 'published' and r.get('request_version') == entry['request_version'] for r in receipts)
        return self._result(entry['id'], {entry['id']: entry['version']},
                            'presented' if shown else 'awaiting_presentation', None)

    def _decide(self, entry):
        receipts = self._presentations(entry)
        return self._project(entry) if receipts is None else self._presented(entry, receipts)

    def project(self):
        """Attempt each pending entry that has no settled record at its request version; return
        one result per pending entry. An entry whose presentations are in use is reported, not sent."""
        return [self._decide(e) for e in self.inbox.index()['entries'] if e['category'] == 'pending']

    def metrics(self):
        if self.presenter is not None:
            m = self.presenter.metrics()
            return dict(self.counts, pending=m['pending'], unknown=m['unknown'], anomalies=m['anomalies'],
                        unpresented_by_reason=m['unpresented_by_reason'])
        records = {e['id']: self.record(projection_id(e['id'], e['request_version']))
                   for e in self.inbox.index()['entries'] if e['category'] == 'pending'}
        return dict(self.counts,
                    pending=sum(1 for r in records.values() if r is None or r['outcome'] in RETRYABLE),
                    unknown=sum(1 for r in records.values() if r is not None and r['outcome'] in ('pending', 'unknown_outcome')),
                    anomalies=sum(1 for r in records.values() if r is not None and r['outcome'] == 'anomaly'))
